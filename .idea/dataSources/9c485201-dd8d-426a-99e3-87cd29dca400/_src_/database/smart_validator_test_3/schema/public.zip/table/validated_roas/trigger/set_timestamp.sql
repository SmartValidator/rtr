CREATE TRIGGER set_timestamp
BEFORE UPDATE ON validated_roas
FOR EACH ROW EXECUTE PROCEDURE update_timestamp()