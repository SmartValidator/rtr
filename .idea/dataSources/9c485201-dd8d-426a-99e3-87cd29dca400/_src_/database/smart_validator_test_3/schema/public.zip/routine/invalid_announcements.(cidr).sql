CREATE FUNCTION invalid_announcements (search_prefix cidr) RETURNS TABLE(announcement_id integer, roa_id integer, announcement_asn bigint, roa_asn bigint, announcement_prefix cidr, roa_max_length integer, announcement_created_at timestamp without time zone, announcement_updated_at timestamp without time zone, roas_created_at timestamp without time zone, roas_updated_at timestamp without time zone)
	LANGUAGE sql
AS $$
  SELECT
    announcements.id          AS announcement_id,
    validated_roas.id         AS roa_id,
    announcements.asn         AS announcement_asn,
    validated_roas.asn        AS roa_asn,
    announcements.prefix      AS announcement_prefix,
    validated_roas.max_length AS roa_max_length,
    announcements.created_at  AS announcement_created_at,
    announcements.updated_at  AS announcement_updated_at,
    validated_roas.created_at AS roa_created_at,
    validated_roas.updated_at AS roa_updated_at
  FROM announcements
    JOIN validated_roas ON (announcements.prefix <<= validated_roas.prefix)
  WHERE announcements.prefix <<= search_prefix AND
        announcements.asn != validated_roas.asn;
  
$$
