CREATE TRIGGER set_timestamp
BEFORE UPDATE ON announcements
FOR EACH ROW EXECUTE PROCEDURE update_timestamp()