CREATE TRIGGER set_timestamp
BEFORE UPDATE ON trust_anchors
FOR EACH ROW EXECUTE PROCEDURE update_timestamp()