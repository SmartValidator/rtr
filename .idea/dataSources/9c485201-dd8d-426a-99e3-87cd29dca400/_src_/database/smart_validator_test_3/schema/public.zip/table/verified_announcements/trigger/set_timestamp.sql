CREATE TRIGGER set_timestamp
BEFORE UPDATE ON verified_announcements
FOR EACH ROW EXECUTE PROCEDURE update_timestamp()